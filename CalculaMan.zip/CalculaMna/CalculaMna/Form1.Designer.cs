﻿namespace CalculaMna
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            label2 = new Label();
            numeroSumA = new Label();
            numeroSumC = new Label();
            numeroSumE = new Label();
            sumNumF = new Label();
            numeroSumB = new Label();
            numeroSumD = new Label();
            sumNumD = new Label();
            a = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            reslSum = new TextBox();
            reslResta = new TextBox();
            reslMulti = new TextBox();
            reslDiv = new TextBox();
            button1 = new Button();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(698, 30);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 0;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // label2
            // 
            label2.Location = new Point(580, 9);
            label2.Name = "label2";
            label2.Size = new Size(95, 23);
            label2.TabIndex = 1;
            label2.Text = "Time left";
            // 
            // numeroSumA
            // 
            numeroSumA.Location = new Point(137, 141);
            numeroSumA.Name = "numeroSumA";
            numeroSumA.Size = new Size(95, 23);
            numeroSumA.TabIndex = 2;
            numeroSumA.Text = "Numero 1";
            // 
            // numeroSumC
            // 
            numeroSumC.Location = new Point(133, 209);
            numeroSumC.Name = "numeroSumC";
            numeroSumC.Size = new Size(95, 23);
            numeroSumC.TabIndex = 3;
            numeroSumC.Text = "Numero 1";
            // 
            // numeroSumE
            // 
            numeroSumE.Location = new Point(133, 268);
            numeroSumE.Name = "numeroSumE";
            numeroSumE.Size = new Size(95, 23);
            numeroSumE.TabIndex = 4;
            numeroSumE.Text = "Numero 1";
            // 
            // sumNumF
            // 
            sumNumF.Location = new Point(133, 329);
            sumNumF.Name = "sumNumF";
            sumNumF.Size = new Size(95, 30);
            sumNumF.TabIndex = 5;
            sumNumF.Text = "Numero 1";
            // 
            // numeroSumB
            // 
            numeroSumB.Location = new Point(288, 144);
            numeroSumB.Name = "numeroSumB";
            numeroSumB.Size = new Size(95, 30);
            numeroSumB.TabIndex = 6;
            numeroSumB.Text = "Numero 1";
            // 
            // numeroSumD
            // 
            numeroSumD.Location = new Point(288, 209);
            numeroSumD.Name = "numeroSumD";
            numeroSumD.Size = new Size(95, 30);
            numeroSumD.TabIndex = 7;
            numeroSumD.Text = "Numero 1";
            // 
            // sumNumD
            // 
            sumNumD.Location = new Point(288, 268);
            sumNumD.Name = "sumNumD";
            sumNumD.Size = new Size(95, 30);
            sumNumD.TabIndex = 8;
            sumNumD.Text = "Numero 1";
            // 
            // a
            // 
            a.Location = new Point(288, 329);
            a.Name = "a";
            a.Size = new Size(95, 30);
            a.TabIndex = 9;
            a.Text = "Numero 1";
            // 
            // label11
            // 
            label11.Location = new Point(238, 144);
            label11.Name = "label11";
            label11.Size = new Size(18, 30);
            label11.TabIndex = 10;
            label11.Text = "+";
            // 
            // label12
            // 
            label12.Location = new Point(239, 202);
            label12.Name = "label12";
            label12.Size = new Size(26, 30);
            label12.TabIndex = 11;
            label12.Text = "-";
            // 
            // label13
            // 
            label13.Location = new Point(239, 271);
            label13.Name = "label13";
            label13.Size = new Size(26, 30);
            label13.TabIndex = 12;
            label13.Text = "*";
            // 
            // label14
            // 
            label14.Location = new Point(238, 329);
            label14.Name = "label14";
            label14.Size = new Size(27, 30);
            label14.TabIndex = 13;
            label14.Text = "÷";
            // 
            // reslSum
            // 
            reslSum.Location = new Point(424, 141);
            reslSum.Name = "reslSum";
            reslSum.Size = new Size(100, 23);
            reslSum.TabIndex = 14;
            // 
            // reslResta
            // 
            reslResta.Location = new Point(424, 209);
            reslResta.Name = "reslResta";
            reslResta.Size = new Size(100, 23);
            reslResta.TabIndex = 15;
            // 
            // reslMulti
            // 
            reslMulti.Location = new Point(424, 268);
            reslMulti.Name = "reslMulti";
            reslMulti.Size = new Size(100, 23);
            reslMulti.TabIndex = 16;
            // 
            // reslDiv
            // 
            reslDiv.Location = new Point(424, 326);
            reslDiv.Name = "reslDiv";
            reslDiv.Size = new Size(100, 23);
            reslDiv.TabIndex = 17;
            // 
            // button1
            // 
            button1.Location = new Point(698, 415);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 18;
            button1.Text = "Send";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(580, 47);
            label3.Name = "label3";
            label3.Size = new Size(105, 15);
            label3.TabIndex = 19;
            label3.Text = "You have 1 minute";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(button1);
            Controls.Add(reslDiv);
            Controls.Add(reslMulti);
            Controls.Add(reslResta);
            Controls.Add(reslSum);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(a);
            Controls.Add(sumNumD);
            Controls.Add(numeroSumD);
            Controls.Add(numeroSumB);
            Controls.Add(sumNumF);
            Controls.Add(numeroSumE);
            Controls.Add(numeroSumC);
            Controls.Add(numeroSumA);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private System.Windows.Forms.Timer timer1;
        private Label label2;
        private Label numeroSumA;
        private Label numeroSumC;
        private Label numeroSumE;
        private Label sumNumF;
        private Label numeroSumB;
        private Label numeroSumD;
        private Label sumNumD;
        private Label a;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private TextBox reslSum;
        private TextBox reslResta;
        private TextBox reslMulti;
        private TextBox reslDiv;
        private Button button1;
        private Label label3;
    }
}
